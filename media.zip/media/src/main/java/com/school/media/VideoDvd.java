package com.school.media;

public class VideoDvd extends Mediateke {
    private String genre;
    private String length;
    private int videoQuality;
    private String title;

    public VideoDvd(String fname,String iType, int size, String author,String title, String length, int quality, String genre){
        super(fname, iType, size, author);
        this.length = length;
        this.videoQuality = quality;
        this.genre = genre;
        this.title = title;
    }
    
    @Override
    void read(){
        System.out.println("Cant open this file.");
    }
    
    @Override
    void playMusic(){
        System.out.println("Cant open this file.");
    }
    
    @Override
    void playVideo(){
        System.out.println("Video Playing ... ");
    }

    @Override
    void openFile(){
        System.out.println("Opening file ... ");
        playVideo();
    }

    @Override
    public String toString(){

        return "Music Filename : " + getfileName()
                + "\nMusic format : " + getitemType()
                + "\nMusic size : " + getsizeInMb() + "mb"
                + "\nMusic Author : " + getauthor()
                + "\nVideo Title : " + this.title
                + "\nVideo Duration : " + this.length
                + "\nVideo genre : " + this.genre
                + "\nVideo quality : " + this.videoQuality;

    }


    void setgenre(String data){
        this.genre = data;
    }
    void settitle(String data){
        this.title = data;
    }
    void setvideoQuality(int data){
        this.videoQuality = data;
    }
    void setlength(String data){
        this.length = data;
    }

    @Override
    String gettitle(){
        return this.title;
    }
    @Override
    String getLength(){
        return this.length;
    }
    String setgenre(){
        return this.genre;
    }
    String settitle(){
        return this.title;
    }
    int setvideoQuality(){
        return this.videoQuality;
    }
    String setlength(){
        return this.length;
    }
}
